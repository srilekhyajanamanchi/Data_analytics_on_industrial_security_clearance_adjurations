pip install vadersentiment

import pandas as pd
from sklearn.model_selection import train_test_split,KFold,cross_val_score
from sklearn.linear_model import LogisticRegression,SGDClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import AdaBoostClassifier,GradientBoostingClassifier,RandomForestClassifier
import seaborn as sns
import pylab as pl
import matplotlib.pyplot as plt
from sklearn.feature_selection import mutual_info_classif
from wordcloud import WordCloud
from sklearn.metrics import roc_curve, auc,f1_score
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from sklearn.metrics import f1_score,precision_score,recall_score,confusion_matrix,classification_report,ConfusionMatrixDisplay

df = pd.read_csv('industrial-security-clearance-decisions.csv')
df.dropna(inplace = True)
df.reset_index(inplace = True)
df.drop(['Unnamed: 0','index'],axis = 1,inplace = True)
df.sample()

df['casenum'].value_counts()

df['keywords'].value_counts()

"""# **CASENUM,KEYWORDS and date don't seem to be useful as they have too many categories and  if used as source columns for model, it might lead to high dimensionality.so, We go ahead with digest textual data to create categories out of it and also to predict the classes**

# **Extracting useful info from Digest  and preprocessing**
"""

a =[ df.loc[i]['digest'].replace(df.loc[i]['casenum'],'').split('.')[-2]  if len(df.loc[i]['digest'].replace(df.loc[i]['casenum'],'').split('.')) >2 else 'not available' for i in range(len(df))  ]

df['extracted_digest'] = a

df

df['extracted_digest'].sample(10)

"""# **Removing Stop Words**"""

from nltk.corpus import stopwords
import nltk
nltk.download('stopwords')
stopwords_list = stopwords.words('english')

a2 = [' '.join([j.lower() for  j in i.replace('sensitive','classified').replace('denied','denied ').split(' ') if (j not in stopwords_list) and len(j) >1 ]) for i in df['extracted_digest']]

keywords_list = pd.Series(' '.join(a2).split(' ')).value_counts()[0:20]

keywords_list

a3 = [' '.join([j for j in i.split() if (j in  keywords_list)  and j not in stopwords_list ]) for i in a2]
len(a3)



z = pd.Series([i if len(i.split(' '))>1 else 'not_enough_keywords' for i in a3 ])
z

"""# **Top 20 most occuring classes** """

plt.figure(figsize = (20,15))
z.value_counts().sort_values(ascending = False)[0:20].plot(kind = 'pie')

z.value_counts().sort_values(ascending = False)[0:25]

"""# Mapping classes with similar meaning to one class"""

word_mappings = {'eligibility security': 'security',
                 'eligibility clearance':'clearance',
                 'eligibility access': 'access',
                 'eligibility position': 'position',
                 'eligibility public': 'public',
                 'request security': 'security',
                 }

new_classes = []
for  i in z:
  for j in word_mappings.keys():
    if j in i:
      #print(i,'-------',j,'----------',i.replace(j,word_mappings[j]))
      i = i.replace(j,word_mappings[j])
    else:
      pass
  new_classes.append(i)
pd.Series(new_classes).value_counts().sort_values(ascending = False)[0:20]

df['new_classes'] = new_classes

value_countings = pd.Series(new_classes).value_counts().sort_values()

df

df['filter'] = [value_countings[i] for i in df['new_classes']]

"""# Filtering out classes occuring rarely"""

filtered_df = df[df['filter']>=40]

plt.bar(x = ['old_categories','quantized_categories'],height =[len(df['new_classes'].unique()),len(filtered_df['new_classes'].unique())])

"""# **Word cloud**"""

digest_list = [i for i in filtered_df['new_classes']]
words = ' '.join([i for word in digest_list for i in word.split()])

wordcloud_review_text = WordCloud(background_color="white").generate(words)
plt.figure(figsize = (20,20))
plt.imshow(wordcloud_review_text, interpolation='bilinear')
plt.axis("off")
plt.show()

"""# **Using  COUNT VECTORIZATION to use the teh extracted digest as predictor** """

from sklearn.feature_extraction.text import CountVectorizer

cv = CountVectorizer(max_features=7000,ngram_range=(1,2),stop_words= list(stopwords_list))

y_cv = filtered_df['new_classes']

x_cv = cv.fit_transform(filtered_df['extracted_digest']).toarray()

"""# **Train and Test the Model**"""

X_cv_train,X_cv_test,y_cv_train,y_cv_test=train_test_split(x_cv,y_cv,test_size=0.2,random_state=42)

model = DecisionTreeClassifier()
model.fit(X_cv_train,y_cv_train)
model.score(X_cv_test,y_cv_test)

predicted_lr_cv_test = model.predict(X_cv_test)
print(confusion_matrix(y_cv_test,predicted_lr_cv_test))
print("-"*50)
plt.figure(figsize = (15,10))
ConfusionMatrixDisplay(confusion_matrix(y_cv_test,predicted_lr_cv_test)).plot()
plt.show()
print("-"*50)
print(classification_report(y_cv_test,predicted_lr_cv_test))

"""**Make the model robust to handle raw data**"""

y_cv = filtered_df['new_classes']
# giving the model the raw uncleaned data
x_cv = cv.fit_transform(filtered_df['digest']).toarray()
X_cv_train,X_cv_test,y_cv_train,y_cv_test=train_test_split(x_cv,y_cv,test_size=0.2,random_state=42)

model = DecisionTreeClassifier()
model.fit(X_cv_train,y_cv_train)
model.score(X_cv_test,y_cv_test)

"""The Score has been decreased after we used raw data. we can choose depending on the scenario

**Sentiment Analysis**
"""

analyzer = SentimentIntensityAnalyzer()
sentiments = []
for i in df['digest']:
  sentiments.append(analyzer.polarity_scores(i)['compound'])

pd.DataFrame([list(df['digest']),sentiments],index = ['digest','sentiment']).T

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense,Dropout

cv = CountVectorizer(max_features=7000,ngram_range=(1,2),stop_words= list(stopwords_list))

x_cv = cv.fit_transform(filtered_df['extracted_digest']).toarray()

model = Sequential()
model.add(Dense(4000, input_shape=(2792,), activation='relu')) # input shape is 5 as the rfe gave top 5 columns
model.add(Dense(5000, activation='relu'))
model.add(Dropout(0.2))                # drop out layers for regularization
# model.add(Dense(24, activation='relu'))
# model.add(Dropout(0.2))
# model.add(Dense(10, activation='relu'))
model.add(Dense(1, activation='softmax'))  # as it is a   model kept the activation as 'sigmoid'

model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

from sklearn import preprocessing
le = preprocessing.LabelEncoder()
y_cv = le.fit_transform(y_cv)

model.fit(x_cv,y_cv, epochs=5, batch_size=200)

