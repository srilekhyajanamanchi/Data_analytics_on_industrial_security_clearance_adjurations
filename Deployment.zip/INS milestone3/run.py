from flask import Flask,render_template,request
import pickle
app = Flask(__name__) 
 
@app.route('/',methods = ['GET','POST'])
def hello_world(): 
    if request.method == 'POST':
        cv = pickle.load(open('count_vector.pkl','rb'))
        model = pickle.load(open('model.pkl','rb'))
        #digest = 'Applicant argues that the Judge improperly focused on his wifeâ€™s contacts in China rather than his foreign contacts.          Applicantâ€™s argument is unpersuasive. As a matter of common sense and human experience, there is a rebuttable presumption that an          applicant has ties of affection for, or obligation to, the immediate family members of his or her spouse. Adverse decision affirmed.           CASE NO: 15-03801.a1'
        values = dict(request.form)
        # print(dict(request.form))
        digest = values['digest'].strip()
        print('*******************')
        #print(model.predict(ote_app_bytes,names_type_tendency]]))
        output = model.predict(cv.transform([digest]))
    else:
        output = 'not predicted yet'      
    return render_template('index.html',output = output)


 
if __name__ == '__main__': 
	app.run(debug = True)