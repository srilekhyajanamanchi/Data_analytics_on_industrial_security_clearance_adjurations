from nltk.corpus import stopwords
import nltk
nltk.download('stopwords')
import pickle
import pandas as pd
from sklearn.model_selection import train_test_split,KFold,cross_val_score
from sklearn.linear_model import LogisticRegression,SGDClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import AdaBoostClassifier,GradientBoostingClassifier,RandomForestClassifier
from sklearn.feature_extraction.text import CountVectorizer

stopwords_list = stopwords.words('english')

cv = CountVectorizer(max_features=7000,ngram_range=(1,2),stop_words= list(stopwords_list))

df = pd.read_csv('cleaned_dataset.csv')

cv.fit(df['digest'])
vector_out = open("count_vector.pkl","wb")
pickle.dump(cv,vector_out)
vector_out.close()
x_cv = cv.transform(df['digest']).toarray()
y_cv = df['new_classes']

model = DecisionTreeClassifier()
model.fit(x_cv,y_cv)
pickle_out = open("model.pkl","wb")
pickle.dump(model,pickle_out)
pickle_out.close()
